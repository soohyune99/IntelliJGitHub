package com.example.byeolbyeolsseudam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByeolbyeolsseudamApplicationTests {

    @Test
    void contextLoads() {
    }

}
