/* mypageCancelList.html */

let $cancelModal = $("#cocoaModal");


/* 취소 상세 모달 열기 */
function cancelModalOpen(){
    $cancelModal.css('display', 'block');
}

/* 취소 상세 모달 닫기 */
function cancelModalClose(){
    $cancelModal.css('display', 'none');
}
