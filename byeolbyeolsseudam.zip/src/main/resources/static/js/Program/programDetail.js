$(function(){ 

    $("#Apply").click(function(){
      $(".modal").fadeIn();
    });
    
    $(".modal_content").click(function(){
      $(".modal").fadeOut();
    });
    
  });